package com.amok.pr16_zykova_as

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    lateinit var login: EditText
    lateinit var pass: EditText
    lateinit var pref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        login = findViewById(R.id.login)
        pass = findViewById(R.id.pass)
    }

    fun handler(v: View){
        if (v.id == R.id.save){
            pref = getPreferences(MODE_PRIVATE)
            val ed = pref.edit()
            ed.putString("login", login.text.toString())
            ed.putString("password", pass.text.toString())
            ed.apply()
        }
        if (v.id == R.id.load){
            pref = getPreferences(MODE_PRIVATE)
            login.setText(pref.getString("login", ""))
            pass.setText(pref.getString("password", ""))
        }
    }
}